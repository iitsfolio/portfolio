<h4>Hello {{$username}},</h4>

<div>
<p><strong>Your current username:</strong> {{$username}}</p>
<p><strong>Your new password:</strong> {{$password}}</p>
</div>
